# dsdn-distributions-yq package

It's a package calculate and plot figure for normal and binomial distribution given data.


## Files

Binomialdistribution.py
Gaussiandistribution.py
Generaldistribution.py

## Installation

#### Dependencies
- python (>= 3.6)
- matplotlib(>= 3.3)
#### Use installation
> pip install -m dsdn_distributions_yq
